#!/bin/bash
unset PYTHONHOME
unset PYTHONPATH
curDIR=`pwd`
/usr/bin/gdb --eval-command="set sysroot $curDIR" --eval-command="core core-postgres-11-1000-1000-128357-1709196198" postgres
